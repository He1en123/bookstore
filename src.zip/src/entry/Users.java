package entry;
import java.sql.*;

import DAO.DBCon;

public class Users {
	String userid;
	String username;
	String password;
	int tel;
	String address;
	float money;
	String role;
	
	public void setusers(String userid,//注册用户
							String username,
							String password,
							int tel,
							String address,
							float money,
							String role) throws ClassNotFoundException, SQLException{
		DBCon a=new DBCon();
		String sql ="insert into users (userid,username,password,tel,address,money)"
				+ " VALUES ('"+userid+"','"+username+"','"+password+"','"+tel+"','"+address+"','"+money+"')";
		Statement stmt = a.getCon().createStatement();
		stmt.executeUpdate(sql);
		stmt.close();
	}
	public int checkusers(String userid,String password)//判断用户存在与否,登录使用
			throws ClassNotFoundException, SQLException{
		DBCon a=new DBCon();
		String sql="select * from user where "
				+ "userid=?  and password=? ";
		PreparedStatement pstmt = a.getCon().prepareStatement(sql);
		pstmt.setString(1, userid);
		pstmt.setString(2, password);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next())
			return 1;
		else 
			return 0;//存在返回1
	}
	
}
